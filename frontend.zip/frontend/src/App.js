import React,{useState}from "react";
import Page from "./components/Page";
import axios from 'axios'

function App() {
  return (
    <div>
      <Page />
    </div>
  );
}
export default App;
